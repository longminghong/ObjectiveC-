//
//  AppDelegate.m
//  12-16
//
//  Created by hehehe on 13-4-10.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    [self.window setAspectRatio:NSMakeSize(300, 100)];
    
    
    NSSize a=[self.window aspectRatio];
    float b=a.width;
    float c=a.height;
    NSLog(@"%f/%f",b,c);

    // Insert code here to initialize your application
}

@end
