//
//  AppDelegate.m
//  12-35
//
//  Created by hehehe on 13-4-11.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    [self.window setHasShadow:NO];
    // Insert code here to initialize your application
}

@end
