//
//  AppDelegate.m
//  12-27
//
//  Created by hehehe on 13-4-11.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    NSSize s=NSMakeSize(500.0, 500.0);
    [self.window setMaxSize:s];
    // Insert code here to initialize your application
}

@end
