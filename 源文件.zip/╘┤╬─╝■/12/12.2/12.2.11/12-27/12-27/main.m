//
//  main.m
//  12-27
//
//  Created by hehehe on 13-4-11.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
