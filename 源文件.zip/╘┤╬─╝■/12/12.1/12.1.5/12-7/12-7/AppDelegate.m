//
//  AppDelegate.m
//  12-7
//
//  Created by hehehe on 13-4-10.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    
     NSRect a=[self.window frame];
     NSPoint b=a.origin;
     float c=b.x;
     float d=b.y;
     NSSize  e=a.size;
     float f=e.width;
     float g=e.height;
     NSLog(@"%f,%f,%f,%f",c,d,f,g);
    // Insert code here to initialize your application
}

@end
