//
//  AppDelegate.m
//  12-2
//
//  Created by hehehe on 13-4-10.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    NSLog(@"%li",[self.window orderedIndex]);
    // Insert code here to initialize your application
}

@end
