//
//  AppDelegate.m
//  12-1
//
//  Created by hehehe on 13-4-10.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    
    NSSize a=[self.window aspectRatio];
    float b=a.width;
    float c=a.height;
    NSLog(@"%f/%f",c,b);
    // Insert code here to initialize your application
}

@end
