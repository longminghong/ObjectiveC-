//
//  AppDelegate.h
//  12-9
//
//  Created by hehehe on 13-4-10.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@property (assign) IBOutlet NSWindow *window;

@end
