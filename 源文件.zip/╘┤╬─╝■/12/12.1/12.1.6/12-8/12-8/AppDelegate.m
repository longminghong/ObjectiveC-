//
//  AppDelegate.m
//  12-8
//
//  Created by hehehe on 13-4-10.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "AppDelegate.h"

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification
{
    NSSize size=[self.window minSize];
    float h=size.height;
    float w=size.width;
    
    NSLog(@"%f,%f",h,w);
    // Insert code here to initialize your application
}

@end
