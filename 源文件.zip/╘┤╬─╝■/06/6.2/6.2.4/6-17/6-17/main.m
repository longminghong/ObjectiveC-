//
//  main.m
//  6-17
//
//  Created by hehehe on 13-3-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSArray *b=[NSArray arrayWithObjects:@"one",@"four",@"two",@"one",@"one", nil];
        NSDictionary *d=[NSDictionary dictionaryWithObjects:b forKeys:a];
        NSLog(@"%@",[d allKeysForObject:@"one"]);
        
        
    }
    return 0;
}

