//
//  main.m
//  6-15
//
//  Created by hehehe on 13-3-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDictionary *d=[[NSDictionary alloc]initWithObjectsAndKeys:@"1",@"one",@"2",@"two",
                         @"3",@"three",@"4",@"four", nil];
        NSLog(@"%@",[d allKeys]);

        
    }
    return 0;
}

