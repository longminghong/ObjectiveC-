//
//  main.m
//  6-7
//
//  Created by hehehe on 13-3-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDictionary *d=[NSDictionary dictionaryWithObjectsAndKeys:@"One",@"1",@"Two",@"2",@"Three",@"3",@"Four",@"4", nil];
        NSLog(@"%@",d);
        
    }
    return 0;
}

