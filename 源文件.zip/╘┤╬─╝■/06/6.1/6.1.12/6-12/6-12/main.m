//
//  main.m
//  6-12
//
//  Created by hehehe on 13-3-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSArray *b=[NSArray arrayWithObjects:@"One",@"Two",@"Three",@"Four",@"Five", nil];
        NSDictionary *d=[[NSDictionary alloc]initWithObjects:b forKeys:a];
        NSLog(@"%@",d);
        
    }
    return 0;
}

