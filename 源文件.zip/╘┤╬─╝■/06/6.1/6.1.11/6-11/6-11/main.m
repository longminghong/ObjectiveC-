//
//  main.m
//  6-11
//
//  Created by hehehe on 13-3-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/12.plist";
        NSDictionary *d=[NSDictionary dictionaryWithContentsOfFile:path];
        NSDictionary *f=[[NSDictionary alloc]initWithDictionary:d];
        NSLog(@"%@",f);
        
    }
    return 0;
}

