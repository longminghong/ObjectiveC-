//
//  main.m
//  6-1
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/NSDictionary.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDictionary *a=[NSDictionary dictionary];
        NSLog(@"%@",a);
        
    }
    return 0;
}

