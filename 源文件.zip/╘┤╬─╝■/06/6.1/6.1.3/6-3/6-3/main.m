//
//  main.m
//  6-3
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/12.plist";
        NSURL *url=[NSURL fileURLWithPath:path];
        NSDictionary *d=[NSDictionary dictionaryWithContentsOfURL:url];
        NSLog(@"d=%@",d);
        NSURL *urll=[NSURL URLWithString:@"http://www.baidu.com"];
        NSDictionary *e=[NSDictionary dictionaryWithContentsOfURL:urll];
        NSLog(@"e=%@",e);
        
        

        
    }
    return 0;
}

