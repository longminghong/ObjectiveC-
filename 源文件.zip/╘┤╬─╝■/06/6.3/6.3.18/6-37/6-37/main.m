//
//  main.m
//  6-37
//
//  Created by hehehe on 13-3-23.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/14.plist";
        NSURL *url=[NSURL fileURLWithPath:path];
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSArray *b=[NSArray arrayWithObjects:@"one",@"two",@"three",@"four",@"five", nil];
        NSDictionary *d=[NSDictionary dictionaryWithObjects:b forKeys:a];
        [d writeToURL:url atomically:YES];

        
    }
    return 0;
}

