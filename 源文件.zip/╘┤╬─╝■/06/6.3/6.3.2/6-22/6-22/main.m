//
//  main.m
//  6-22
//
//  Created by hehehe on 13-3-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=@"/Users/hehehe/Desktop/12.plist";
        NSDictionary *d=[[NSFileManager defaultManager] attributesOfItemAtPath:a error:nil];
        NSLog(@"%@",[d fileModificationDate]);
        
    }
    return 0;
}

