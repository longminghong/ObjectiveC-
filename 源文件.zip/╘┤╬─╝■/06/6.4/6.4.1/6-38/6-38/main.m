//
//  main.m
//  6-38
//
//  Created by hehehe on 13-3-23.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSArray *b=[NSArray arrayWithObjects:@"one",@"two",@"three",@"four",@"five", nil];
        NSDictionary *d=[NSDictionary dictionaryWithObjects:b forKeys:a];
        NSLog(@"%li",[d count]);


        
    }
    return 0;
}

