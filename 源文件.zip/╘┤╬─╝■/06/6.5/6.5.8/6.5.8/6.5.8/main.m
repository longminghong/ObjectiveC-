//
//  main.m
//  6.5.8
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSArray *b=[NSArray arrayWithObjects:@"a",@"b",@"c",@"d",@"e", nil];
        NSMutableDictionary *d=[NSMutableDictionary dictionaryWithObjects:a forKeys:b];
        
        NSLog(@"添加前%@",d);
        [d removeObjectsForKeys:b];
        NSMutableDictionary *f=[NSDictionary dictionaryWithObjectsAndKeys:@"6",@"f",@"7",@"g",@"8",@"h", nil];
        [d addEntriesFromDictionary:f];
    
        
        NSLog(@"添加后%@", f);
    }
    return 0;
}

