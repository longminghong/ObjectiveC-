//
//  main.m
//  6-41
//
//  Created by hehehe on 13-3-23.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableDictionary *d=[NSMutableDictionary dictionaryWithCapacity:40];
        
    }
    return 0;
}

