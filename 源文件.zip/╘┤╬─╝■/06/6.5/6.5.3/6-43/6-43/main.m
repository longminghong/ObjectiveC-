//
//  main.m
//  6-43
//
//  Created by hehehe on 13-3-23.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableDictionary *d=[[NSMutableDictionary alloc]init];
        [d setObject:@"1" forKey:@"a"];
        [d setObject:@"2" forKey:@"b"];
        [d setObject:@"3" forKey:@"c"];
        [d setObject:@"4" forKey:@"d"];
        NSLog(@"%@",d);
        
    }
    return 0;
}

