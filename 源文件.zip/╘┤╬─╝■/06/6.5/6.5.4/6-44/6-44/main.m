//
//  main.m
//  6-44
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
      
        NSDictionary *d=[NSDictionary dictionaryWithObjectsAndKeys:@"1",@"a",@"2",@"b",@"3",@"c",@"4",@"d", nil];
        NSMutableDictionary *f=[[NSMutableDictionary alloc]init];
        [f setDictionary:d];
        NSLog(@"f=%@",f);

        
        
        
    }
    return 0;
}

