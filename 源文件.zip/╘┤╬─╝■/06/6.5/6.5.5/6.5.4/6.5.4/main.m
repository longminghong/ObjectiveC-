//
//  main.m
//  6.5.4
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSArray *b=[NSArray arrayWithObjects:@"a",@"b",@"c",@"d",@"e", nil];
        NSMutableDictionary *d=[NSMutableDictionary dictionaryWithObjects:a forKeys:b];
     
        NSLog(@"删除前%@",d);
        [d removeAllObjects];
     
        NSLog(@"删除后%@",d);
    
    
    }
    return 0;
}

