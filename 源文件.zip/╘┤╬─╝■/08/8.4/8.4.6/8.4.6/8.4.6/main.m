//
//  main.m
//  8.4.6
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/002";
        NSString *p=@"/Users/hehehe/Desktop/003";
        NSFileManager *ma=[NSFileManager defaultManager];
        if([ma contentsEqualAtPath:path andPath:p]){
            NSLog(@"文件相等");
        }else{
            NSLog(@"文件不相等");
        }

        
    }
    return 0;
}

