//
//  main.m
//  8.4.1
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       NSString *path=@"/Users/hehehe/Desktop/002";
        NSFileManager *ma=[NSFileManager defaultManager];
        if([ma fileExistsAtPath:path]){
            NSLog(@"文件存在");
        }else{
            NSLog(@"文件不存在");
        }
    }
    return 0;
}

