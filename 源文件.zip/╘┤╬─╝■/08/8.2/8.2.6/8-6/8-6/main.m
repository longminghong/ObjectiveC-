//
//  main.m
//  8-6
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path1=@"/Users/hehehe/Desktop/副本111";
        NSFileManager *manager=[NSFileManager defaultManager];
        NSDictionary *d=[NSDictionary dictionaryWithObject:[NSNumber numberWithBool:YES] forKey:NSFileExtensionHidden];
        [manager setAttributes:d ofItemAtPath:path1 error:nil];
       
        NSLog(@"%@",[manager attributesOfItemAtPath:path1 error:nil]);
 
        

    }
    return 0;
}

