//
//  main.m
//  8-4
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path1=@"/Users/hehehe/Desktop/haha/111";
        
        NSFileManager *manager=[NSFileManager defaultManager];
        [manager removeItemAtPath:path1 error:nil];
      
        
    }
    return 0;
}

