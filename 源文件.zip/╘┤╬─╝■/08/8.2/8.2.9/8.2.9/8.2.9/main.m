//
//  main.m
//  8.2.9
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *dirName=@"/Users/hehehe/Desktop/8.2.8/022";
        
        NSFileManager *fm=[NSFileManager defaultManager];
      
      
        [fm createDirectoryAtPath:dirName withIntermediateDirectories:NO attributes:nil error:nil];
      
        
        
    }
    return 0;
}

