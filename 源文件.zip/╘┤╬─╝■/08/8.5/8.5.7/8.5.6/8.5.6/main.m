//
//  main.m
//  8.5.6
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSString *path=@"/Users/hehehe/Desktop/002";
        NSString *path1=@"/Users/hehehe/Desktop/004";
        
        NSFileHandle *handle=[NSFileHandle fileHandleForReadingAtPath:path];
        NSFileHandle *ha=[NSFileHandle fileHandleForWritingAtPath:path1];
        NSData *data=[handle readDataOfLength:(5)];
        [ha writeData:data];
        NSLog(@"%@",[NSString stringWithContentsOfFile:path1 encoding:NSASCIIStringEncoding error:nil]);

        

        
    }
    return 0;
}

