//
//  main.m
//  8.5.9
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=@"/Users/hehehe/Desktop/002";
        NSFileHandle *h=[NSFileHandle fileHandleForReadingAtPath:a];
        NSLog(@"设置前%lli",[h offsetInFile]);
        [h seekToFileOffset:10];
        NSLog(@"设置后%lli",[h offsetInFile]);
        
        
        
    }
    return 0;
}

