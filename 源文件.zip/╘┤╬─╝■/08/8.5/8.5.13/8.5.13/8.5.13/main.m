//
//  main.m
//  8.5.13
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/002";
        NSFileHandle *handle=[NSFileHandle fileHandleForReadingAtPath:path];
        [handle closeFile];
        
    }
    return 0;
}

