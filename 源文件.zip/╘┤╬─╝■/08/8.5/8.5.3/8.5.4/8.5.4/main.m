//
//  main.m
//  8.5.4
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/002";
        NSFileHandle *handle=[NSFileHandle fileHandleForWritingAtPath:path];
        if(handle!=nil){
            NSLog(@"打开文件进行写入操作成功");
        }else{
            NSLog(@"打开文件进行写入操作失败");
            
        }
        
    }
    return 0;
}

