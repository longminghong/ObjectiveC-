//
//  main.m
//  8.5.12
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path1=@"/Users/hehehe/Desktop/002";
        NSString *path2=@"/Users/hehehe/Desktop/004";
        
        NSFileHandle *h1=[NSFileHandle fileHandleForReadingAtPath:path1];
        NSFileHandle *h2=[NSFileHandle fileHandleForWritingAtPath:path2];
        NSData *d=[h1 availableData];
        [h2 writeData:d];
        NSLog(@"%@",[NSString stringWithContentsOfFile:path2 encoding:NSASCIIStringEncoding error:nil]);
        
        

    }
    return 0;
}

