﻿//
//  main.m
//  8.5.5
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
          NSString *path=@"/Users/hehehe/Desktop/100";
        NSFileHandle *handle=[NSFileHandle fileHandleForUpdatingAtPath:path];		
        if(handle!=nil){
            NSLog(@"打开文件进行更新操作成功");
        }else{
            NSLog(@"打开文件进行更新操作失败");
        }
       
    }
    return 0;
}

