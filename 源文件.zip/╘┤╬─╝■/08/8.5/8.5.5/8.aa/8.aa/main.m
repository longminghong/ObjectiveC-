//
//  main.m
//  8.aa
//
//  Created by hehehe on 13-5-17.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *p1=@"/Users/hehehe/Desktop/002";
        NSString *p2=@"/Users/hehehe/Desktop/004";
        NSFileManager *ma=[NSFileManager defaultManager];
        NSFileHandle *h=[NSFileHandle fileHandleForWritingAtPath:p2];
        NSData *d=[ma contentsAtPath:p1];
        [h writeData:d];

        
    }
    return 0;
}

