//
//  main.m
//  8.5.8
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=@"/Users/hehehe/Desktop/002";
        NSFileHandle *h=[NSFileHandle fileHandleForReadingAtPath:a];
        NSLog(@"%lli",[h offsetInFile]);
        [h readDataToEndOfFile];
        NSLog(@"%lli",[h offsetInFile]);
        
                         
    }
    return 0;
}

