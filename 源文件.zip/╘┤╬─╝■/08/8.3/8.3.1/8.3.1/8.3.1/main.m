//
//  main.m
//  8.3.1
//
//  Created by hehehe on 13-3-26.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/002";
        
        NSFileManager *fm=[NSFileManager defaultManager];
        NSLog(@"%@",[fm contentsAtPath:path]);
        
        
        NSLog(@"%@",[NSString stringWithContentsOfFile:path encoding:NSASCIIStringEncoding error:nil]);
        

        
    }
    return 0;
}

