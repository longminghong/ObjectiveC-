//
//  main.m
//  11-30
//
//  Created by hehehe on 13-4-6.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSDictionary *a=[NSDictionary dictionaryWithObjectsAndKeys:@"1",@"a",@"2",@"b",@"3",@"c", nil];
        NSMutableData *d=[[NSMutableData alloc]init];
        NSKeyedArchiver *k=[[NSKeyedArchiver alloc]initForWritingWithMutableData:d];
        [k encodeObject:a forKey:@"Some Key Value"];
        [k finishEncoding];
        [NSKeyedArchiver archiveRootObject:d toFile:@"/Users/hehehe/Desktop/6.plist"];
     
      
        
        
    }
    return 0;
}

