//
//  main.m
//  11-31
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDictionary *d=[NSDictionary dictionaryWithObjectsAndKeys:@"1",@"a",@"2",@"c",@"3",@"d", nil];
        NSData *a=[NSKeyedArchiver archivedDataWithRootObject:d];
        [a writeToFile:@"/Users/hehehe/Desktop/5.plist" atomically:YES];
        
    }
    return 0;
}

