//
//  main.m
//  11-100
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDictionary *a=[NSDictionary dictionaryWithObjectsAndKeys:@"aa",@"bb",@"cc",@"dd", nil];
        [NSKeyedArchiver archiveRootObject:a toFile:@"/Users/hehehe/Desktop/11.plist"];
        
    }
    return 0;
}

