//
//  aa.m
//  11-36
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
@synthesize name;
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeObject:name forKey:@"MemberName"];
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    name=[[aDecoder decodeObjectForKey:@"MemberName"]retain];
    return self;
}
@end
