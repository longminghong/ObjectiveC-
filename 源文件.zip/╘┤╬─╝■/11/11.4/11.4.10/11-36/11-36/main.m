//
//  main.m
//  11-36
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        aa *a=[[aa alloc]init];
        aa *b;
        [a setName:@"Tom"];
        [NSKeyedArchiver archiveRootObject:a toFile:@"/Users/hehehe/Desktop/100.plist"];
        b=[NSKeyedUnarchiver unarchiveObjectWithFile:@"/Users/hehehe/Desktop/100.plist"];
        NSLog(@"name is %@",[b name]);
        
    }
    return 0;
}

