//
//  aa.h
//  11-36
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface aa : NSObject<NSCoding>{
    NSString *name;
}
@property(nonatomic,copy) NSString *name;
@end
