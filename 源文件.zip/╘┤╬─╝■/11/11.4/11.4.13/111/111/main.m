//
//  main.m
//  111
//
//  Created by hehehe on 13-4-8.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSDictionary *a=[NSDictionary dictionaryWithObjectsAndKeys:@"1",@"a",@"2",@"b",
                         @"3",@"c", nil];
        NSMutableData *d=[[NSMutableData alloc]init];
        NSKeyedArchiver *k=[[NSKeyedArchiver alloc]initForWritingWithMutableData:d];
        [k encodeObject:a forKey:@"Some Key Value"];
        [k finishEncoding];
        
        
        [NSKeyedArchiver archiveRootObject:d  toFile:@"/Users/hehehe/Desktop/10.plist"];
        
        
        
        NSData *m=[[NSData alloc]initWithContentsOfFile:@"/Users/hehehe/Desktop/10.plist"];
        NSKeyedUnarchiver *un=[[NSKeyedUnarchiver alloc]initForReadingWithData:m];
        NSDictionary *g=[un decodeObjectForKey:@"Some Key Value"];
        [un finishDecoding];
       

      
        

        
    }
    return 0;
}

