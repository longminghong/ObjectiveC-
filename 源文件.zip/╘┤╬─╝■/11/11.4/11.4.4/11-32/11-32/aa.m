//
//  aa.m
//  11-32
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
@synthesize ba;
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeBool:ba forKey:@"MemberBa"];
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    ba=[aDecoder decodeBoolForKey:@"MemberBa"];
    return self;
}

@end
