//
//  main.m
//  11-32
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        aa *b=[[aa alloc]init];
        aa *c;
        [b setBa:1];
        [NSKeyedArchiver archiveRootObject:b toFile:@"/Users/hehehe/Desktop/555.plist"];
        c=[NSKeyedUnarchiver unarchiveObjectWithFile:@"/Users/hehehe/Desktop/555.plist"];
      
        NSLog(@"%i", [c ba]) ;
        
    }
    return 0;
}

