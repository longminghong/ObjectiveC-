//
//  aa.m
//  11-34
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
@synthesize fla;
@synthesize flb;
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeFloat:fla forKey:@"MemberFla"];
    [aCoder encodeDouble:flb forKey:@"MemberFlb"];
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    fla=[aDecoder decodeFloatForKey:@"MemberFla"];
    flb=[aDecoder decodeDoubleForKey:@"MemberFlb"];
    return self;
}

@end
