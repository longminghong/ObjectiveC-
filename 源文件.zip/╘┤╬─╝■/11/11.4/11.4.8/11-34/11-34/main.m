//
//  main.m
//  11-34
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        aa *a=[[aa alloc]init];
        aa *b;
        [a setFla:1.56];
        [a setFlb:3333333.6];
        [NSKeyedArchiver archiveRootObject:a toFile:@"/Users/hehehe/Desktop/888.plist"];
        b=[NSKeyedUnarchiver unarchiveObjectWithFile:@"/Users/hehehe/Desktop/888.plist"];
        NSLog(@"fla=%f",[b fla]);
        NSLog(@"flb=%f",[b flb]);
        
        
    }
    return 0;
}

