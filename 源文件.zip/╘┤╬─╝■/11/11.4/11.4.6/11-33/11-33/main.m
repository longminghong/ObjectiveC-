//
//  main.m
//  11-33
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        aa *a=[[aa alloc]init];
        aa *b;
        
        [a setAge:30];
        [NSKeyedArchiver archiveRootObject:a toFile:@"/Users/hehehe/Desktop/666.plist"];
        b=[NSKeyedUnarchiver unarchiveObjectWithFile:@"/Users/hehehe/Desktop/666.plist"];
        NSLog(@"%i",[b age]);
        
        
    }
    return 0;
}

