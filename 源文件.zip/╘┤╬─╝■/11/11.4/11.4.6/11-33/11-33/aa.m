//
//  aa.m
//  11-33
//
//  Created by hehehe on 13-4-7.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
@synthesize age;
-(void)encodeWithCoder:(NSCoder *)aCoder{
    [aCoder encodeInt:age forKey:@"MenberAge"];
}
-(id)initWithCoder:(NSCoder *)aDecoder{
    age=[aDecoder decodeIntForKey:@"MenberAge"];
    return self;
}
@end
