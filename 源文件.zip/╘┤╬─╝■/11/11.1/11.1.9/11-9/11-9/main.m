//
//  main.m
//  11-9
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSURL *url=[NSURL URLWithString:@"http://www.baidu.com"];
        NSData *a=[[NSData alloc]initWithContentsOfURL:url];
        NSLog(@"%@",a);

        
    }
    return 0;
}

