//
//  main.m
//  11-11
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSData *d=[NSData data];
        char a=[d bytes];
        NSLog(@"%hhd",a);
    }
    return 0;
}

