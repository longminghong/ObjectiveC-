//
//  main.m
//  11-13
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=@"I Love China";
        NSData *d=[a dataUsingEncoding:NSUTF8StringEncoding];
        NSLog(@"%li",[d length]);
    }
    return 0;
}

