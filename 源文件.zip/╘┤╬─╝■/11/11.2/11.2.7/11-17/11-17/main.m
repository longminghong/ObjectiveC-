//
//  main.m
//  11-17
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSString *a=@"I Love Objective-C";
        NSData *d1=[a dataUsingEncoding:NSUTF8StringEncoding];
        
        NSString *path=@"/Users/hehehe/Desktop/1";
        NSURL *url=[NSURL fileURLWithPath:path];
        [d1 writeToURL:url atomically:YES];
        
    }
    return 0;
}

