//
//  main.m
//  11-16
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a1=@"I Love China";
        NSData *d1=[a1 dataUsingEncoding:NSUTF8StringEncoding];
        NSString *path=@"/Users/hehehe/Desktop/1";
        [d1 writeToFile:path atomically:YES];
       
    }
    return 0;
}

