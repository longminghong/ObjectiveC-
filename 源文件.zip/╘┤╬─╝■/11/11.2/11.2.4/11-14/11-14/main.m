//
//  main.m
//  11-14
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a1=@"I Love China";
        NSData *d1=[a1 dataUsingEncoding:NSUTF8StringEncoding];
        NSString *a2=@"hehehehehe";
        NSData *d2=[a2 dataUsingEncoding:NSUTF8StringEncoding];
        if([d1 isEqualToData:d2]){
            NSLog(@"两个数据对象相等");
        }else{
            NSLog(@"两个数据对象不相等");
        }
        
        
        
    }
    return 0;
}

