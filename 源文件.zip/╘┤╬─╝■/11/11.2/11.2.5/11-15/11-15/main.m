//
//  main.m
//  11-15
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSRange range=NSMakeRange(0, 6);
        
        NSString *a1=@"I Love China";
        NSData *d1=[a1 dataUsingEncoding:NSUTF8StringEncoding];
        NSData *d2=[d1 subdataWithRange:range];
        NSLog(@"%@",d2);
        NSString *c=[[NSString alloc]initWithData:d2 encoding:NSUTF8StringEncoding];
        NSLog(@"%@",c);

        
    }
    return 0;
}

