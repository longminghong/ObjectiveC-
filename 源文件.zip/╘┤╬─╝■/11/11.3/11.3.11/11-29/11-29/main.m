//
//  main.m
//  11-29
//
//  Created by hehehe on 13-4-3.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        char c1[]="I Love Objective-C";
        NSMutableData *d=[NSMutableData dataWithBytes:c1 length:18];
        char *a=[d mutableBytes];
        NSLog(@"删除前%s",a);
        NSRange range=NSMakeRange(10, 18);
        [d resetBytesInRange:range];
        char *a1=[d mutableBytes];
        NSLog(@"删除后%s",a1);

        
        
        
        
    }
    return 0;
}

