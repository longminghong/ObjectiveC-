//
//  main.m
//  11-25
//
//  Created by hehehe on 13-4-3.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        char c[]="I Love Objective-C";
        NSMutableData *d=[NSMutableData dataWithBytes:c length:5];
        NSString *n1=[[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding];
   
        NSLog(@"添加前%@",n1);
        [d appendBytes:c length:10];
        NSString *n2=[[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding];
        NSLog(@"添加后%@",n2);
       
    }
    return 0;
}

