//
//  main.m
//  11-19
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableData *d=[NSMutableData dataWithCapacity:40];
    }
    return 0;
}

