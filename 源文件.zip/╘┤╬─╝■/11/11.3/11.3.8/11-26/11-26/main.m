//
//  main.m
//  11-26
//
//  Created by hehehe on 13-4-3.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       
        char c1[]="I Love";
        NSMutableData *d=[NSMutableData dataWithBytes:c1 length:6];
        NSString *n1=[[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding];
        NSLog(@"添加前＝%@",n1);
        char c2[]="Objective-C";
        NSData *a=[NSData dataWithBytes:c2 length:11];
        [d appendData:a];
        NSString *n2=[[NSString alloc]initWithData:d encoding:NSUTF8StringEncoding];
        NSLog(@"添加后＝%@",n2);
        

       
    }
    return 0;
}

