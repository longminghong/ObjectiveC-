//
//  main.m
//  11-23
//
//  Created by hehehe on 13-4-3.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
       

        
        NSMutableData *d=[[NSMutableData alloc]init];
         NSLog(@"设置前%@",d);
        NSString *a=@"I Love China";
        NSData *d1=[a dataUsingEncoding:NSUTF8StringEncoding];

        [d setData:d1];
        
        NSLog(@"设置后%@",d);
    }
    return 0;
}

