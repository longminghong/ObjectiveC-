//
//  main.m
//  11-28
//
//  Created by hehehe on 13-4-3.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        char c1[]="I Love Objective-C";
        NSMutableData *d=[NSMutableData dataWithBytes:c1 length:18];
        char *a=[d mutableBytes];
        NSLog(@"替换前＝%s",a);
        char c2[]="China";
        NSRange range=NSMakeRange(7, 10);
        [d replaceBytesInRange:range withBytes:c2];
        char *f=[d mutableBytes];
        NSLog(@"替换后＝%s",f);
        
        
        
        
    }
    return 0;
}

