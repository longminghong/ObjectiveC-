//
//  main.m
//  4-27
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=@"I Love ";
        NSString *b=@"Love";
        if([a rangeOfString:b].location!=NSNotFound){
            
            NSLog(@"b在字符串a中");
        }else{
            NSLog(@"b不在字符串a中");
        }
    }
    
    return 0;
}

