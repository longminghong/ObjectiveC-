//
//  main.m
//  4-31
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
      NSString *Path = @"~/1.aa";
        NSLog(@"Extension:%@",[Path pathExtension]);
    }
    return 0;
}

