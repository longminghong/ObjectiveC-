//
//  main.m
//  4-50
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path = @"/User/mike/textFile";
          NSLog(@"%@",path);
        path = [path stringByAppendingPathExtension: @"txt"];
        NSLog(@"%@",path);
        
    }
    return 0;
}

