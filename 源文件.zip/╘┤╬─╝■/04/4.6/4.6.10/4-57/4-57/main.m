//
//  main.m
//  4-57
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=@"~";
        NSString *b=@"fixt.doc";
        NSString *originalPath = [a stringByAppendingPathComponent: b];
        NSString *o = [b stringByAppendingPathComponent: a];
        NSLog(@"%@",originalPath);
        NSLog(@"%@",o);
        
    }
    return 0;
}

