//
//  main.m
//  4-58
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *Path = @"/Users/hehehe/NSData.txt";
      
        NSString *a=[Path stringByAbbreviatingWithTildeInPath];
        NSLog(@"%@",a);

   
        
    }
    return 0;
}

