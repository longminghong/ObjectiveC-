//
//  main.m
//  455
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/2";
        NSURL *url=[NSURL fileURLWithPath:path];
        NSString *s=@"Objective-C!!!";
        [s writeToURL:url atomically:YES encoding:NSASCIIStringEncoding error:nil];
        
    }
    return 0;
}

