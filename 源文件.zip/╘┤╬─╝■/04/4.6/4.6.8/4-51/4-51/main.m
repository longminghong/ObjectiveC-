//
//  main.m
//  4-51
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *thisColumn = @"/Users/mike/Documents/Cocoa_Column/Column8.doc";
        NSLog(@"%@",thisColumn);
        NSString *lastComponent = [thisColumn lastPathComponent];
        NSLog(@"%@",lastComponent);

        

        
    }
    return 0;
}

