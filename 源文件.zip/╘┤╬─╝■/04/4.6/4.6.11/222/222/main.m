//
//  main.m
//  222
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=@"~/1.txt";
        if([a isAbsolutePath]==YES){
            NSLog(@"此路径为绝对路径");
        }else{
            NSLog(@"此路径不是绝对路径");
        }
        
       
        
        
        
    }
    return 0;
}

