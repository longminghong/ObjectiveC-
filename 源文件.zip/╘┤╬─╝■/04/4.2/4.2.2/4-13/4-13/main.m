//
//  main.m
//  4-13
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=[NSString stringWithCString:"ABCDEF" encoding:NSASCIIStringEncoding];
        if([a hasPrefix:@"B"]==YES){
            NSLog(@"开头为字母B");
        }else{
             NSLog(@"开头不为字母B");
            
        }
        
        
    }
    return 0;
}

