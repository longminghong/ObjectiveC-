//
//  main.m
//  4-15
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=[NSString stringWithCString:"ABCDEF" encoding:NSASCIIStringEncoding];
        NSString *b=[NSString stringWithCString:"abcdef" encoding:NSASCIIStringEncoding];
        if([a compare:b]==NSOrderedAscending){
            NSLog(@"字符串a小于字符串b");
        }else if([a compare:b]==NSOrderedSame){
            NSLog(@"字符串a等于字符串b");
        }else{
            NSLog(@"字符串a大于字符串b");
        }

        
    }
    return 0;
}

