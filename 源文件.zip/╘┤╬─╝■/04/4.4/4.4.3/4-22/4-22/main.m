//
//  main.m
//  4-22
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=[NSString stringWithCString:"abcdefghijk" encoding:NSASCIIStringEncoding];
        NSRange rang1=NSMakeRange(2, 5);
        
        NSLog(@"%@",[a substringWithRange:rang1]);
        
    }
    return 0;
}

