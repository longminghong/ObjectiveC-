//
//  main.m
//  4-28
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       NSString *a=@"123abc";
        NSLog(@"%f",[a doubleValue]);

 
        
        
    }
    return 0;
}

