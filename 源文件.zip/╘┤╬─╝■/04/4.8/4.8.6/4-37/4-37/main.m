//
//  main.m
//  4-37
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSMutableString *a = [[NSMutableString alloc] initWithString:@"I Love China"];
    
        
        [a insertString:@"Hi! " atIndex:0];
        NSLog(@"String1:%@",a);
        
    }
    return 0;
}

