//
//  main.m
//  4-34
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       NSString *a=@"I Love ";
        NSMutableString *b=[NSMutableString stringWithString:a];
        [b appendString:@"China"];
        NSLog(@"%@",b);
        
    }
    return 0;
}

