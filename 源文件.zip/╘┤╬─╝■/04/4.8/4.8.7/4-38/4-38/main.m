//
//  main.m
//  4-38
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSRange rang=NSMakeRange(0, 3);
        NSMutableString *a=[[NSMutableString alloc]initWithString:@"Hi!I Love China"];
        NSLog(@"%@",a);
        [a deleteCharactersInRange:rang];
        NSLog(@"%@",a);
        
    }
    return 0;
}

