//
//  main.m
//  4-45
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableString *a=[[NSMutableString alloc]initWithString:@"abcaddaabb"];
        NSLog(@"%@",a);
        NSRange range=NSMakeRange(0, 9);
        [a replaceOccurrencesOfString:@"a" withString:@"f" options:NSLiteralSearch range:range];
        NSLog(@"%@",a);
        
    }
    return 0;
}

