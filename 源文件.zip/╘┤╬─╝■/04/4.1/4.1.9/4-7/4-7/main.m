//
//  main.m
//  4-7
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSString *a=@"aaaaa";
        NSString *b=[[NSString alloc]initWithString:a];
        NSLog(@"%@",b);
        
        
    }
    return 0;
}

