//
//  main.m
//  4-1
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/NSString.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *a=[NSString string];
        NSLog(@"%@",a);
        
    }
    return 0;
}

