//
//  main.m
//  4-40
//
//  Created by hehehe on 13-3-19.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
        
        NSLog(@"url = %@",url);
        
        NSString *pageContents  = [NSString stringWithContentsOfURL:url encoding:NSASCIIStringEncoding error:nil];
        
        NSLog(@"pageContents = %@",pageContents);

        
        
      
        
    }
    return 0;
}

