//
//  aa.h
//  10-18
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface aa : NSObject
-(void)print;

@end
