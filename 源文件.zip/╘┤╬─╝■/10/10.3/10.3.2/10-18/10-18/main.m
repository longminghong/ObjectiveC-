//
//  main.m
//  10-18
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        aa *b=[[aa alloc]init];
        
        int i;
        for(i=1;i<10;i++){
            NSThread *tt=[[NSThread alloc]initWithTarget:b selector:@selector(print) object:nil];
            [tt start];
            if(i==5){
                [tt cancel];
            }
            
        }
            
        
            
        
        
       
    }
    return 0;
}

