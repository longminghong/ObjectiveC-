//
//  aa.m
//  10-18
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
-(void)print{
    NSLog(@"aa");
}

@end
