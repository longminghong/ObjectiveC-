//
//  main.m
//  10-17
//
//  Created by hehehe on 13-3-31.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        aa *b=[[aa alloc]init];
        
        NSThread *tt=[[NSThread alloc]initWithTarget:b selector:@selector(print) object:nil];
        [tt start];
    }
    return 0;
}

