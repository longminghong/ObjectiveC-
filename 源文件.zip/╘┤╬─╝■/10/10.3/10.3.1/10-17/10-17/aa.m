//
//  aa.m
//  10-17
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
-(void)print{
    NSLog(@"线程");
    
}

@end
