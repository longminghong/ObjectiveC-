//
//  main.m
//  10-21
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       NSThread *t=[NSThread currentThread];
        NSLog(@"更改前%f",[t threadPriority]);
        [t setThreadPriority:0.8];

        NSLog(@"更改后%f",[t threadPriority]);
    }
    return 0;
}

