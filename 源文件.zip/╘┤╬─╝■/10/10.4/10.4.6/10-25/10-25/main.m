//
//  main.m
//  10-25
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSThread *t=[NSThread currentThread];
        NSLog(@"%lu",[t stackSize]);
 
     
        
    }
    return 0;
}

