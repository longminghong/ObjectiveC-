//
//  main.m
//  10-26a
//
//  Created by hehehe on 13-5-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSThread *t=[NSThread currentThread];
        NSLog(@"设置前%lu",[t stackSize]);
        [t setStackSize:12*4096];					
        NSLog(@"设置后%lu",[t stackSize]);

        
    }
    return 0;
}

