//
//  main.m
//  10.8.3
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        aa *b=[[aa alloc]init];
        aa *d=[[aa alloc]init];
        c=[[NSConditionLock alloc]initWithCondition:1];

        NSThread *t1=[[NSThread alloc]initWithTarget:b selector:@selector(print1) object:nil];
        [t1 start];
       
         NSThread *t2=[[NSThread alloc]initWithTarget:d selector:@selector(print2) object:nil];
        [t2 start];
          

            
        
    
    
        
    }
    return 0;
}

