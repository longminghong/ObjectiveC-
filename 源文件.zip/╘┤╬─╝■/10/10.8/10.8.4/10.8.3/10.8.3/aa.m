//
//  aa.m
//  10.8.3
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
-(void)print1{
    for(int i=1;i<=5;i++){
       [c lockWhenCondition:1];
        NSLog(@"i=%i",i);
        [c unlockWithCondition:1];   
    }
}
-(void)print2{
    for(int x=1;x<=5;x++){
        NSLog(@"x=%i",x);
    }
}
@end
