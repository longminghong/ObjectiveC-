//
//  main.m
//  10.8.2
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSConditionLock *clock=[[NSConditionLock alloc]initWithCondition:1];
        NSLog(@"%li",[clock condition]);
    }
    return 0;
}

