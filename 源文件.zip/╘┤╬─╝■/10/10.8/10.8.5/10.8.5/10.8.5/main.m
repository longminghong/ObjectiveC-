//
//  main.m
//  10.8.5
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSConditionLock *c=[[NSConditionLock alloc]initWithCondition:0];
        if([c tryLockWhenCondition:0]){
            NSLog(@"获取锁");
        }else{
            NSLog(@"没有获取锁");
        }
        
    }
    return 0;
}

