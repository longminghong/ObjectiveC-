//
//  main.m
//  10.8.8
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *date=[NSDate date];
        NSConditionLock *c=[[NSConditionLock alloc]initWithCondition:0];
        if([c lockBeforeDate:date]){
            NSLog(@"获取锁");
        }else{
            NSLog(@"没有获取锁");
        }
        
    }
    return 0;
}

