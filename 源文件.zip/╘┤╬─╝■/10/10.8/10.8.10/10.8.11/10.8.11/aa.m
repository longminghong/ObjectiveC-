//
//  aa.m
//  10.8.11
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
-(void)print{
    for(int i=1;i<=5;i++){
        [c lock];
        NSLog(@"i=%i",i);
        [c unlock];
    }
}

@end
