//
//  main.m
//  10.8.11
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        aa *b=[[aa alloc]init];
        c=[[NSConditionLock alloc]initWithCondition:0];
        NSThread *t=[[NSThread alloc]initWithTarget:b selector:@selector(print) object:nil];
        [t start];
        for(int x=1;x<=5;x++){
        
            NSLog(@"x=%i",x);
        
        }
        
        
        
    }
    return 0;
}

