//
//  aa.h
//  10.8.11
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
NSConditionLock *c;

@interface aa : NSObject
-(void)print;

@end
