//
//  main.m
//  10-33
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
      
        NSLock *lock=[[NSLock alloc]init];
     
   
        if([lock tryLock]){
            NSLog(@"锁定锁");
        }else{
            NSLog(@"不能锁定锁");
        }

        
    }
    return 0;
}

