//
//  main.m
//  10-34
//
//  Created by hehehe on 13-4-2.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *d=[NSDate date];

        NSLock *lock=[[NSLock alloc]init];
        if([lock lockBeforeDate:d]){
            NSLog(@"锁定锁");
        }else{
            NSLog(@"没有锁定锁");
        }

        
    }
    return 0;
}

