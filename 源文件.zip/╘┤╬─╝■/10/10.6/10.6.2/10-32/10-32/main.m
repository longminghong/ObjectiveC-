//
//  main.m
//  10-32
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        aa *b=[[aa alloc]init];
        int x;
        lock = [[NSLock alloc] init];
        [NSThread detachNewThreadSelector:@selector(print:) toTarget:b withObject:nil];
        
        for(x=0;x<10;++x)
        {
            [lock lock];
            NSLog(@"Main thread says x is %i\n",x);
          
            [lock unlock];
           
        }
        NSLog(@"==Main thread return==");
     
        
        
        
    }
    return 0;
}

