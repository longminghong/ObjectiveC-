//
//  aa.m
//  10-32
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"


@implementation aa
-(void)print:(id)parm{
    int x;
    for(x=0;x<10;++x)
    {
        [lock lock];
        NSLog(@"Object Thread says x is %i\n",x);
        [lock unlock];
    }
    NSLog(@"==Object thread return==");
    return;
    
}


@end
