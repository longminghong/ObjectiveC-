//
//  main.m
//  10-8
//
//  Created by hehe on 13-6-27.
//  Copyright (c) 2013年 hehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSProcessInfo *p=[NSProcessInfo processInfo];
        NSString *n=[p operatingSystemVersionString];
        NSLog(@"%@",n);
   
    }
    return 0;
}

