//
//  main.m
//  10-12
//
//  Created by hehehe on 13-3-31.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSProcessInfo *p=[NSProcessInfo processInfo];
        NSString *n=[p processName];
        NSLog(@"设置前%@",n);
        [p setProcessName:@"yyyyy"];
        NSString *n1=[p processName];
        NSLog(@"设置后%@",n1);
      
        
        
    }
    return 0;
}

