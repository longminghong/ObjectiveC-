//
//  main.m
//  10-9
//
//  Created by hehehe on 13-3-31.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSProcessInfo *p=[NSProcessInfo processInfo];
        NSLog(@"%i",[p processIdentifier]);
        
    }
    return 0;
}

