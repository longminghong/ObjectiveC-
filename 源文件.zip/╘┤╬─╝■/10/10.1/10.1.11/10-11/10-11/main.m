//
//  main.m
//  10-11
//
//  Created by hehehe on 13-3-31.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSProcessInfo *p=[NSProcessInfo processInfo];
        NSString *n=[p hostName];
        NSLog(@"%@",n);
      

        
    }
    return 0;
}

