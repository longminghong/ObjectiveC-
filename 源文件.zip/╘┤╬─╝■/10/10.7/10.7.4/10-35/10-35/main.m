//
//  main.m
//  10-35
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        aa *b=[[aa alloc]init];
        int x;
        rlock = [[NSRecursiveLock alloc] init];
        [NSThread detachNewThreadSelector:@selector(print) toTarget:b withObject:nil];
        for(x=1;x<5;++x)
        {
            
            NSLog(@"x= %i\n",x);
            
        }
        if([rlock tryLock]){
            NSLog(@"锁定锁");
        }else{
            NSLog(@"没有锁定锁");
        }
        
    }
    return 0;
}

