//
//  main.m
//  10-14
//
//  Created by hehehe on 13-3-31.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "aa.h"

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        aa *b=[[aa alloc]init];
        
        [NSThread detachNewThreadSelector:@selector(print) toTarget:b withObject:nil];
        
    }
    return 0;
}

