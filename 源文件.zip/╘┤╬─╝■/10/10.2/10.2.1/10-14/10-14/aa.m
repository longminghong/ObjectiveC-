//
//  aa.m
//  10-14
//
//  Created by hehehe on 13-3-31.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import "aa.h"

@implementation aa
-(void)print{
    NSLog(@"线程");
}

@end
