//
//  aa.h
//  10-14
//
//  Created by hehehe on 13-3-31.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface aa : NSObject
-(void)print;

@end
