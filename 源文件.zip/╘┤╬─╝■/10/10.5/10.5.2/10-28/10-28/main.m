//
//  main.m
//  10-28
//
//  Created by hehehe on 13-5-22.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSThread *t=[[NSThread alloc]init];
        [t start];
        if([t isExecuting]){
            NSLog(@"线程正在执行");
        }else{
            NSLog(@"线程没有执行");
        }

        
    }
    return 0;
}

