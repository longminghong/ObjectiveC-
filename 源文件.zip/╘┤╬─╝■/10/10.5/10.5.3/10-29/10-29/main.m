//
//  main.m
//  10-29
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSThread *t=[[NSThread alloc]init];
        [t start];
        [t cancel];
        if([t isCancelled]){
            NSLog(@"线程取消");
        }else{
            NSLog(@"线程没有取消");
        }

        
    }
    return 0;
}

