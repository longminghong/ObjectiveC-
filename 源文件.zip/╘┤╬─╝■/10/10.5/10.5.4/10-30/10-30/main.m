//
//  main.m
//  10-30
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSThread *t=[[NSThread alloc]init];
        [t start];
        if([t isFinished]){
            NSLog(@"线程结束");
        }else{
            NSLog(@"线程没有结束");
        }
        

        
    }
    return 0;
}

