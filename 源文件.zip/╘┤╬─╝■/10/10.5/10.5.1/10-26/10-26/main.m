//
//  main.m
//  10-26
//
//  Created by hehehe on 13-4-1.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSThread *t=[[NSThread alloc]init];
        if([t isMainThread]){
            NSLog(@"线程为主线程");
        }else{
            NSLog(@"线程不是主线程");
        }
        
    }
    return 0;
}

