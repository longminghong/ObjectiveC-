//
//  main.m
//  Hello World
//
//  Created by hehehe on 13-3-13.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSLog(@"Hello, Objective-C");
        
    }
    return 0;
}

