//
//  main.m
//  2-1
//
//  Created by hehehe on 13-2-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <math.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
     
    
         NSLog(@"%i  ",rand());
         NSLog(@"%i  ",rand());
         NSLog(@"%i  ",rand());
     

    }
    return 0;
}

