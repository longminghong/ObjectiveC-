//
//  main.m
//  2-5
//
//  Created by hehehe on 13-2-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSLog(@"%f",ceil(-3.14159));
        NSLog(@"%f",ceil(0));
        NSLog(@"%f",ceil(3.14159));
    }
    return 0;
}

