//
//  main.m
//  2-4
//
//  Created by hehehe on 13-2-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
 
        NSLog(@"%f",floor(-3.14159));
        NSLog(@"%f",floor(0));
        NSLog(@"%f",floor(3.14159));
        
        
    }
    return 0;
}

