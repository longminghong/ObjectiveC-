//
//  main.m
//  2-15
//
//  Created by hehehe on 13-3-13.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        double a,b;
        double c;
        b=8.222;
        a=modf(b, &c);
        NSLog(@"整数部分为%f",c);
        NSLog(@"小数部分为%f",a);
      
        
        
    }
    return 0;
}

