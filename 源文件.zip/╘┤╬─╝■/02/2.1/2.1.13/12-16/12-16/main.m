//
//  main.m
//  12-16
//
//  Created by hehehe on 13-3-14.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        double a,b;
        int c;
        b=8.0000;
        a=frexp(b, &c);
        NSLog(@"指数为%i",c);
        NSLog(@"尾数为%f",a);
        double d=-8.0000;
        NSLog(@"\n");
        a=frexp(d, &c);
        NSLog(@"指数为%i",c);
        NSLog(@"尾数为%f",a);

        

        
       
        
    }
    return 0;
}

