//
//  main.m
//  2-7
//
//  Created by hehehe on 13-2-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <math.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
   
        NSLog(@"%f",sqrt(4));
        NSLog(@"%f",sqrt(0));
        NSLog(@"%f",sqrt(-4));
  
        
    }
    return 0;
}

