//
//  main.m
//  2-13
//
//  Created by hehehe on 13-3-13.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSLog(@"%f",hypot(6,8));
        NSLog(@"%f",hypot(1, 0));
        
    }
    return 0;
}

