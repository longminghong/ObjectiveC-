//
//  main.m
//  2-14
//
//  Created by hehehe on 13-3-13.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSLog(@"%f",fmod(10,2));
        NSLog(@"%f",fmod(9,2));
        NSLog(@"%f",fmod(100,0));
    }
    return 0;
}

