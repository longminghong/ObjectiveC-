//
//  main.m
//  2-12
//
//  Created by hehehe on 13-3-13.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSLog(@"%f",fmin(50,fmin(20,30)));
        
    }
    return 0;
}

