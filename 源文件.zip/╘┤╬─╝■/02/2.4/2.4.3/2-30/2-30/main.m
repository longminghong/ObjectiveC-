//
//  main.m
//  2-30
//
//  Created by hehehe on 13-3-14.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSLog(@"%f",exp2(5));
        
    }
    return 0;
}

