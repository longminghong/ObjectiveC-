//
//  main.m
//  2-32
//
//  Created by hehehe on 13-3-14.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSLog(@"%f",log10(10));
    }
    return 0;
}

