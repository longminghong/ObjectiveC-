//
//  main.m
//  2-6
//
//  Created by hehehe on 13-2-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
 
        NSLog(@"%f",pow(2,3));
 
        
    }
    return 0;
}

