//
//  main.m
//  2-28
//
//  Created by hehehe on 13-3-14.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        float a;
        float b;
        a=atanh(0.5);
        b=a*180/3.1415926;
        NSLog(@"%f",b);
        a=atanh(1.1);
        b=a*180/3.1415926;
        NSLog(@"%f",b);

        

    
        
    }
    return 0;
}

