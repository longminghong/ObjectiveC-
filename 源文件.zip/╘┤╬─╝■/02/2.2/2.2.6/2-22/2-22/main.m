//
//  main.m
//  2-22
//
//  Created by hehehe on 13-3-14.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#define K (0.017453292519943295769236907684886l)


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
     
        NSLog(@"%f",tanh(-0.5*K));
        NSLog(@"%f",tanh(0.5*K));
  
        
        
    }
    return 0;
}

