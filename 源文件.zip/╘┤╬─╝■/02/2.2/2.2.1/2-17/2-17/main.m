//
//  main.m
//  2-17
//
//  Created by hehehe on 13-3-14.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#define K (0.017453292519943295769236907684886l)

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSLog(@"%f",sin(K*30));
    }
    return 0;
}

