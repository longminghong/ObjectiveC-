//
//  main.m
//  5-31
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSString *path=@"/Users/hehehe/Desktop/素材";
        
        NSArray *fileList = [[[NSFileManager defaultManager] contentsOfDirectoryAtPath:path error:nil]
pathsMatchingExtensions:[NSArray arrayWithObject:@"jpg"]] ;
         
        NSLog(@"%@",fileList);

        
    }
    return 0;
}

