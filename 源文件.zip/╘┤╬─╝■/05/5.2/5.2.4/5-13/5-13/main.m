//
//  main.m
//  5-13
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[[NSArray alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSLog(@"%@",[a lastObject]);
        
    }
    return 0;
}

