//
//  main.m
//  5-23
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       NSString *a=@"A,B,C,D,E,F,G";
       NSArray *b=[a componentsSeparatedByString:@","];
       NSLog(@"%@",b);
        
        NSString *c=@"ABCD";
        NSArray *d=[c componentsSeparatedByString:@","];
        NSLog(@"%@",d);

        
        
        


    
        
    }
    return 0;
}

