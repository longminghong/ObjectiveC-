//
//  main.m
//  5-33
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
NSInteger pai(id st,id str,void *ch){
    if([st integerValue]<[str integerValue] ){
        return NSOrderedDescending;
    }else if ([st integerValue]>[str integerValue]){
        return NSOrderedAscending;
    }else{
        return NSOrderedSame;
    }
 
}


int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"5",@"2",@"3",@"2",@"6",@"1", nil];
        
        NSArray *b=[a sortedArrayUsingFunction:pai context:nil];
        NSLog(@"%@",b);
        
        
    }
    return 0;
}

