//
//  main.m
//  5-14
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"a",@"b",@"c", nil];
        NSLog(@"位置为2的元素是%@",[a objectAtIndex:2]);
        
    }
    return 0;
}

