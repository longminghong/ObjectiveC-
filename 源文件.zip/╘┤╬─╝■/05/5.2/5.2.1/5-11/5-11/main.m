//
//  main.m
//  5-11
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *s=[[NSArray alloc]initWithObjects:@"1",@"2",@"3", nil];
        if([s containsObject:@"8"]==1){
            NSLog(@"数组中有8这个元素");
        }else{
            NSLog(@"数组中没有8这个元素");
        }
        
    }
    return 0;
}

