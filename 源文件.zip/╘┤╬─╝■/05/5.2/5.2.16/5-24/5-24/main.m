//
//  main.m
//  5-24
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSString *path=@"/Users/hehehe/Desktop/12.plist";
        
        NSArray *a=[NSArray arrayWithObjects:@"a",@"b",@"c",@"d",nil];
        [a writeToFile:path atomically:YES];
        
    }
    return 0;
}

