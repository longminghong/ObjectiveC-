//
//  main.m
//  5.2.9
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSRange rang=NSMakeRange(0, 3);
        
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
       NSArray *b= [a subarrayWithRange:rang];
        NSLog(@"%@",b);
        
    }
    return 0;
}

