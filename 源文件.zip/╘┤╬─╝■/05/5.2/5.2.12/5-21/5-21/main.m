//
//  main.m
//  5-21
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"a",@"b",@"c", nil];
        NSLog(@"%li",[a indexOfObjectIdenticalTo:@"c"]);
        
    }
    return 0;
}

