//
//  main.m
//  5-16
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSLog(@"%@",[a arrayByAddingObject:@"a"]);
        
    }
    return 0;
}

