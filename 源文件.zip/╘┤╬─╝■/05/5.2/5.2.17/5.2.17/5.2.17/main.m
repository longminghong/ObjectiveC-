//
//  main.m
//  5.2.17
//
//  Created by hehehe on 13-5-17.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/13.plist";
        NSURL *url=[NSURL fileURLWithPath:path];
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3", @"4",@"5",nil];
        [a writeToURL:url atomically:YES];			
        
    }
    return 0;
}

