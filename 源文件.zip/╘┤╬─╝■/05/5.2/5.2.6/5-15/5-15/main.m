//
//  main.m
//  5-15
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSIndexSet *b=[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, 5)];
        
        NSArray *a=[NSArray arrayWithObjects:@"1",@"2",@"3", @"4",@"5",nil];
        NSLog(@"%@",[a objectsAtIndexes:b]);
        
    }
    return 0;
}

