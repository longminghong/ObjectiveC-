//
//  main.m
//  5-22
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[NSArray arrayWithObjects:@"a",@"b",@"c", nil];
        NSString *b=[a componentsJoinedByString:@","];
        NSLog(@"%@",b);
        
        
    }
    return 0;
}

