//
//  main.m
//  5-3
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSString *path=@"/Users/hehehe/Desktop/12.plist";
    
        NSArray *a=[NSArray arrayWithContentsOfFile:path];
        NSLog(@"%@",a);
   
   
        
    }
    return 0;
}

