//
//  main.m
//  5-9
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSURL *url = [NSURL URLWithString:@"http://icodeblog.com/samples/nsoperation/data.plist"];
        NSLog(@"url = %@",url);
        NSArray *array=[[NSArray alloc]initWithContentsOfURL:url];
        NSLog(@"array=%@",array);

        
    }
    return 0;
}

