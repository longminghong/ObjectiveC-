//
//  main.m
//  5-aa
//
//  Created by hehehe on 13-5-17.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSArray *a=[[NSArray alloc]init];
        
    }
    return 0;
}

