//
//  main.m
//  5.3.8
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *a=[NSMutableArray arrayWithObjects:@"a",@"b",@"c",@"d",@"e",nil];
        
        NSLog(@"删除前%@",a);
        [a   removeObjectAtIndex:3];
        NSLog(@"删除后%@",a);
        
    }
    return 0;
}

