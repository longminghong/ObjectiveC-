//
//  main.m
//  5.3.13
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSMutableArray *a=[NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSLog(@"替换前%@",a);
        NSArray *array=[NSArray arrayWithObjects:@"aaaaa",@"bbbbb",@"cccc", nil];
        NSIndexSet *set=[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, 3)];
      
        [a replaceObjectsAtIndexes:set withObjects:array];
        NSLog(@"替换后%@",a);

        
    }
    return 0;
}

