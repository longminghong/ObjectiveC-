//
//  main.m
//  5.3.15
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *a=[NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSLog(@"插入前%@",a);
        [a insertObject:@"aaa" atIndex:2];
        NSLog(@"插入后%@",a);
        
    }
    return 0;
}

