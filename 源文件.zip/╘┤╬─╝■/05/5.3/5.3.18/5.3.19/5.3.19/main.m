//
//  main.m
//  5.3.19
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *a=[[NSMutableArray alloc]init];
        NSArray *array=[NSArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        [a setArray:array];
        NSLog(@"%@",a);
        
    }
    return 0;
}

