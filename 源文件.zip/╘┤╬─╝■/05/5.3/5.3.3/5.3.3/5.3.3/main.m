//
//  main.m
//  5.3.3
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *a=[[NSMutableArray alloc]initWithCapacity:40];
        [a addObject:@"a"];
        [a addObject:@"b"];
        [a addObject:@"c"];
        NSLog(@"%@",a);
        
    }
    return 0;
}

