//
//  main.m
//  5.3.17
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *a=[NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSLog(@"插入前%@",a);
        NSIndexSet *set=[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0, 3)];
        NSArray *array=[NSArray arrayWithObjects:@"aa",@"bb",@"cc", nil];
        [a insertObjects:array atIndexes:set];
        NSLog(@"插入后%@",a);

        
    }
    return 0;
}

