//
//  main.m
//  5.3.12
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *a=[NSMutableArray arrayWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSLog(@"替换前%@",a);
        [a replaceObjectAtIndex:2 withObject:@"aaaa"];
         NSLog(@"替换后%@",a);
   
        
    }
    return 0;
}

