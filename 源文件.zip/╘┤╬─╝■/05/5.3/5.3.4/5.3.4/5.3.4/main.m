//
//  main.m
//  5.3.4
//
//  Created by hehehe on 13-3-21.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSArray *array=[NSArray arrayWithObjects:@"a",@"b",@"C",@"d",@"e", nil];
        
        NSMutableArray *a=[[NSMutableArray alloc]init];
        [a addObjectsFromArray:array];
        NSLog(@"%@",a);
    }
    return 0;
}

