//
//  main.m
//  5.3.1
//
//  Created by hehehe on 13-3-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableArray *a=[NSMutableArray arrayWithCapacity:0];
     
        
        
    }
    return 0;
}

