//
//  main.m
//  9.2.1
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *d1=[NSDate date];
        NSDate *d2=[NSDate dateWithNaturalLanguageString:@"2010-12-12"];
        if([d1 isEqualToDate:d2]){
            NSLog(@"两时间相等");
        }else{
            NSLog(@"两时间不相等");
        }
        
    }
    return 0;
}

