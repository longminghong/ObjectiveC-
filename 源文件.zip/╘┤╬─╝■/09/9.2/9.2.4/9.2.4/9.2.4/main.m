//
//  main.m
//  9.2.4
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSDate *d1=[NSDate date];
        NSDate *d2=[NSDate dateWithNaturalLanguageString:@"2010-5-22"];
        NSLog(@"%@时间较晚",[d1 laterDate:d2]);
        
    }
    return 0;
}

