//
//  main.m
//  9.2.2
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *d1=[NSDate date];
        NSDate *d2=[NSDate dateWithNaturalLanguageString:@"2010-12-12"];
        if([d1 compare:d2]==NSOrderedDescending){
            NSLog(@"%@时间较大",d1);
        }else{
            NSLog(@"%@时间较大",d2);
        }
    }
    return 0;
}

