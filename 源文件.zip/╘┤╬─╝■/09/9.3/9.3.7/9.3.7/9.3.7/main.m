//
//  main.m
//  9.3.7
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *d=[NSDate dateWithNaturalLanguageString:@"2013-3-27 00:00:00 +0000"];
        NSLog(@"%f",[d timeIntervalSinceReferenceDate]);
        
    }
    return 0;
}

