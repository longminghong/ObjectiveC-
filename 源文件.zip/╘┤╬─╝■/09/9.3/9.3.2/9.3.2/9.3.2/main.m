//
//  main.m
//  9.3.2
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *d=[NSDate distantPast];
        NSLog(@"%@",d);
    }
    return 0;
}

