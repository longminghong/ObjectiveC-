//
//  main.m
//  9.3.4
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *d1=[NSDate date];
        NSDate *d2=[NSDate dateWithNaturalLanguageString:@"2013-3-27 00:00:00 +0000"];
        NSLog(@"%f",[d1 timeIntervalSinceDate:d2]);
        NSLog(@"%f",[d2 timeIntervalSinceDate:d1]);
    }
    return 0;
}

