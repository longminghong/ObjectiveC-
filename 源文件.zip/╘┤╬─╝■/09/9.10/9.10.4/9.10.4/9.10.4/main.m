//
//  main.m
//  9.10.4
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSTimer *t=[[NSTimer alloc]initWithFireDate:nil interval:0.5 target:nil selector:nil userInfo:nil repeats:YES];
        NSDate *d=[NSDate dateWithNaturalLanguageString:@"2013-3-29"];
        [t setFireDate:d];
        NSLog(@"%@",[t fireDate]);
        
    }
    return 0;
}

