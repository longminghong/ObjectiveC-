//
//  main.m
//  9.10.5
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSTimer *t=[NSTimer timerWithTimeInterval:0.5 invocation:nil repeats:YES];
        [t invalidate];
        
        
    }
    return 0;
}

