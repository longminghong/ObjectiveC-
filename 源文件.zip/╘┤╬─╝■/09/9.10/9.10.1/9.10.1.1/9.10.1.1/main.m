﻿//
//  main.m
//  9.10.1.1
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
         NSTimer *timer1=[NSTimer timerWithTimeInterval:0.5 target:nil  selector:nil userInfo:nil repeats:YES];        
    }
    return 0;
}

