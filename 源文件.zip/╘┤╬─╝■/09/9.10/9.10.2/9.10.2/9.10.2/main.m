﻿//
//  main.m
//  9.10.2
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/NSTimer.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
       
        
        NSTimer *timer=[[NSTimer alloc]initWithFireDate:nil interval:0.5 target:nil selector:nil userInfo:nil repeats:YES];
        
    }
    return 0;
}

