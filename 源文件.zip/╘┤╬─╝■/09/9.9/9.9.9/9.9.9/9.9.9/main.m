//
//  main.m
//  9.9.9
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSTimeZone *z=[NSTimeZone timeZoneWithName:@"America/Chicago"];
        NSLog(@"缩写前%@",z);
        NSLog(@"缩写后%@",[z abbreviation]);
    }
    return 0;
}

