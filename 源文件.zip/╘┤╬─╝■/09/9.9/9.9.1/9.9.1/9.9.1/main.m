//
//  main.m
//  9.9.1
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/NSTimeZone.h>
int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSTimeZone *z=[NSTimeZone timeZoneWithName:@"America/Chicago"];
        NSLog(@"%@",z);
        NSTimeZone *z1=[NSTimeZone timeZoneWithName:@"America/aa"];
        NSLog(@"%@",z1);
        
        
    }
    return 0;
}

