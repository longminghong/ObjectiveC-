//
//  main.m
//  9.4.2
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDateFormatter *f=[[NSDateFormatter alloc]initWithDateFormat:@"%Y %b %d" allowNaturalLanguage:YES];
        NSDate *d=[NSDate date];
        NSString *da=[f stringFromDate:d];
        NSLog(@"%@",da);
        
        
    }
    return 0;
}

