//
//  main.m
//  9.4.3
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDateFormatter *f=[[NSDateFormatter alloc]init];
        [f setDateFormat:@"yy//MM//dd HH:mm:ss"];
        NSDate *d=[NSDate date];
        NSString *date=[f stringFromDate:d];
        NSLog(@"%@",date);
        
    }
    return 0;
}

