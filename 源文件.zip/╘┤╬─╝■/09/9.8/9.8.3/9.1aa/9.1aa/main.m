//
//  main.m
//  9.1aa
//
//  Created by hehehe on 13-5-20.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSCalendar *c=[[NSCalendar alloc]initWithCalendarIdentifier:NSGregorianCalendar];        
    }
    return 0;
}

