//
//  main.m
//  9.1.1
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/NSDate.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSDate *date=[NSDate date];
        NSLog(@"%@",date);
        
        
        
    }
    return 0;
}

