//
//  main.m
//  9.1.10
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *date1=[NSDate date];
        NSDate *date2=[[NSDate alloc]initWithTimeInterval:(24*60*60) sinceDate:date1];
        NSLog(@"%@",date2);
    }
    return 0;
}

