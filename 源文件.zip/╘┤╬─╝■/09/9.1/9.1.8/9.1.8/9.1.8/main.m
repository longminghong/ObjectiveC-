//
//  main.m
//  9.1.8
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *date=[[NSDate alloc]init];
        NSLog(@"%@",date);
        
    }
    return 0;
}

