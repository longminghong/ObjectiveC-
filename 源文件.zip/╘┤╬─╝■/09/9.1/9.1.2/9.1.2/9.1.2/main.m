//
//  main.m
//  9.1.2
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSDate *date1=[NSDate dateWithString:@"2010-12-25 00:00:00 -0600"];
        NSLog(@"date1=%@",date1);
        NSDate *date2=[NSDate dateWithString:@"aa"];
        NSLog(@"date2=%@",date2);
        
    }
    return 0;
}

