//
//  main.m
//  9.7.10
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSCalendarDate *c=[NSCalendarDate calendarDate];
        NSLog(@"%li",[c yearOfCommonEra]);
    }
    return 0;
}

