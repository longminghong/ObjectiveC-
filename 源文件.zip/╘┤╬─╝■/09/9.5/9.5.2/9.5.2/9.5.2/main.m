//
//  main.m
//  9.5.2
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSCalendarDate *c=[NSCalendarDate dateWithYear:2012 month:12 day:12 hour:12 minute:12 second:12 timeZone:nil];
        NSLog(@"%@",c);
        
    }
    return 0;
}

