//
//  main.m
//  9.6.2
//
//  Created by hehehe on 13-3-28.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
       
        
        NSCalendarDate *hotTime = [NSCalendarDate dateWithYear:2011 month:2 day:3 hour:14 minute:0 second:0 timeZone:nil];
        NSLog(@"设置前的时区%@",[hotTime timeZone]);
        NSTimeZone *pacific = [NSTimeZone timeZoneWithName:@"PST"];
        
        [hotTime setTimeZone:pacific];
        NSLog(@"设置后的时区%@",[hotTime timeZone]);
        
        
    }
    return 0;
}

