//
//  main.m
//  3-7
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSNumber *a=[NSNumber numberWithDouble:112233e+16];
        NSLog(@"%f",[a doubleValue]);
        NSLog(@"%lg",[a doubleValue]);

        
    }
    return 0;
}

