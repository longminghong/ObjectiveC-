//
//  main.m
//  3-8
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSNumber *a=[[NSNumber alloc]initWithDouble:1.555*10e100];
        NSLog(@"%lg",[a doubleValue]);
    }
    return 0;
}

