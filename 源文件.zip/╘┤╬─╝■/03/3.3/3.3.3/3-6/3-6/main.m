//
//  main.m
//  3-6
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSNumber *a=[[NSNumber alloc]initWithFloat:-8.55];
        NSLog(@"%f",[a floatValue]);
        
    }
    return 0;
}

