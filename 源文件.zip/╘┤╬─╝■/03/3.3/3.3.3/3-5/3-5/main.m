//
//  main.m
//  3-5
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSNumber *a=[NSNumber numberWithFloat:3.000];
        NSLog(@"%f",[a floatValue]);
        
    }
    return 0;
}

