//
//  main.m
//  3-3
//
//  Created by hehehe on 13-3-17.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSNumber *a=[NSNumber numberWithChar:'k'];
        NSLog(@"%c",[a charValue]);
        
        
    }
    return 0;
}

