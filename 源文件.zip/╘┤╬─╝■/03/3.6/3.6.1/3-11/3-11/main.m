//
//  main.m
//  3-11
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSNumber *a=[NSNumber numberWithInt:10];
        NSNumber *b=[NSNumber numberWithInt:-10];
        if([a isEqualToNumber:b]==1){
            NSLog(@"相等");
        }else{
            NSLog(@"不相等");
        }
        
    }
    return 0;
}

