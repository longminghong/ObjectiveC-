//
//  main.m
//  3-12
//
//  Created by hehehe on 13-3-18.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSNumber *c=[NSNumber numberWithChar:'k'];
        NSNumber *d=[NSNumber numberWithChar:'a'];
        if([c compare:d]==NSOrderedAscending){
            NSLog(@"%c小",[c charValue]);
        }else{
             NSLog(@"%c小",[d charValue]);
            
        }
        
    }
    return 0;
}

