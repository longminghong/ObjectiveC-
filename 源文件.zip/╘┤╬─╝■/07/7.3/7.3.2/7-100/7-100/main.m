//
//  main.m
//  7-100
//
//  Created by hehehe on 13-3-27.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSSet *s=[NSSet setWithObjects:@"1",@"2",@"3",@"4", nil];
        NSLog(@"%@",[s member:@"3"]);
        NSLog(@"%@",[s member:@"%6"]);
    }
    return 0;
}

