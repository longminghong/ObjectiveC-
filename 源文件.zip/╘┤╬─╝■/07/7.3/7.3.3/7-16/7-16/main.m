//
//  main.m
//  7-16
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSSet *s=[NSSet setWithObjects:@"1",@"2",@"3", nil];
        NSSet *ss=[NSSet setWithObjects:@"a",@"b",@"c",@"1",@"2",@"3", nil];
        if([s isSubsetOfSet:ss]){
            NSLog(@"集合s是集合ss的子集");
        }else{
            NSLog(@"集合s不是集合ss的子集");
        }
    }
    return 0;
}

