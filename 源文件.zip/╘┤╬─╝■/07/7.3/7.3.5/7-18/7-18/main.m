//
//  main.m
//  7-18
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSSet *s=[NSSet setWithObjects:@"1",@"2",@"3", nil];
        NSSet *ss=[NSSet setWithObjects:@"a",@"b",@"c",@"1",@"2",@"3", nil];
        if([s isEqualToSet:ss]){
            NSLog(@"两集合相等");
        }else{
            NSLog(@"两集合不相等");
        }
        
    }
    return 0;
}

