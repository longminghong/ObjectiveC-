//
//  main.m
//  7-14
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSSet *s=[[NSSet alloc]initWithObjects:@"1",@"2",@"3", nil];
        if([s containsObject:@"3"]){
            NSLog(@"集合中有3这个元素");
        }else{
            NSLog(@"集合中没有3这个元素");
        }
        
    }
    return 0;
}

