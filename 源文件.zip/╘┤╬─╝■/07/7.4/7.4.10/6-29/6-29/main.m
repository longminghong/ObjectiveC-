//
//  main.m
//  6-29
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableSet *s=[NSMutableSet setWithObjects:@"a",@"1",@"2",@"3",nil];
        NSLog(@"s=%@",s);
        NSSet *a=[NSSet setWithObjects:@"1",@"2",@"3", nil];
        NSLog(@"a=%@",a);
        [s intersectSet:a];
        NSLog(@"交集为%@",s);
        
        

        
    }
    return 0;
}

