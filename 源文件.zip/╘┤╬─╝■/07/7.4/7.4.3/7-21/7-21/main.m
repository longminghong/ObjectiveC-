//
//  main.m
//  7-21
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSSet *ss=[NSSet setWithObjects:@"a",@"b",@"c", nil];
        NSLog(@"ss=%@",ss);
        
        NSMutableSet *s=[NSMutableSet set];
        [s setSet:ss];
        NSLog(@"s=%@",s);
    }
    return 0;
}

