//
//  main.m
//  7-22
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableSet *s=[NSMutableSet set];
        [s addObject:@"a"];
        [s addObject:@"b"];
        [s addObject:@"c"];
        NSLog(@"%@",s);
    }
    return 0;
}

