//
//  main.m
//  7-27
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        
        NSMutableSet *s=[NSMutableSet setWithObjects:@"a",@"b",@"c", nil];
        NSLog(@"添加前%@",s);
        NSSet *a=[NSSet setWithObjects:@"1",@"2",@"3", nil];
        [s unionSet:a];
        NSLog(@"添加后%@",s);
        
    }
    return 0;
}

