//
//  main.m
//  7-24
//
//  Created by hehehe on 13-3-25.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSMutableSet *s=[NSMutableSet set];
        [s addObject:@"a"];
        [s addObject:@"b"];
        [s addObject:@"c"];
        NSLog(@"删除前%@",s);
        [s removeAllObjects];
         NSLog(@"删除后%@",s);
        
        
    }
    return 0;
}

