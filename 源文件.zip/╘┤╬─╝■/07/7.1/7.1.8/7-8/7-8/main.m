//
//  main.m
//  7-8
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSSet *s=[[NSSet alloc]initWithObjects:@"1",@"2",@"3",@"4",@"5", nil];
        NSLog(@"%@",s);
        
               
    }
    return 0;
}

