//
//  main.m
//  46
//
//  Created by hehehe on 13-3-24.
//  Copyright (c) 2013年 hehehe. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        NSSet *s=[NSSet set];
        NSLog(@"%@",s);
    
      
        
        
        
    }
    return 0;
}

